export class Anuncio{
    constructor(id, titulo, transaccion, descripcion, precio, imagen){
        this.titulo = titulo;
        this.transaccion = transaccion;
        this.descripcion = descripcion;
        this.precio = precio;
        this.id = id;
        this.imagen = imagen;
    }
}